function [A, EM] = row_mult(A, row, k)

EM = eye(size(A, 1));
EM(row, row) = k;
A = EM * A;

end