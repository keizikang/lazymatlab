function [A, EM] = row_swit(A, row1, row2)

EM = eye(size(A, 1));
EM([row1, row2], :) = EM([row2, row1], :);
A = EM * A;

end