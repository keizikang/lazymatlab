function [A, EM] = row_add(A, from, to, k)

EM = eye(size(A, 1));
EM(to, from) = k;
A = EM * A;

end